const str = {
  "connectionString": "mongodb+srv://interview:welcome2byteridge@byteridge-hdrl6.mongodb.net/interview",
  "secret": "JBJYBJ23jkj232kALKMLAK"
}

module.exports = str;
